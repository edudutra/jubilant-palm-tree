#!/bin/bash

TRANSPORT_KEY=/home/wso2carbon/7comm/fluxo-consents-scripts/certs/transport.key
TRANSPORT_CERT=/home/wso2carbon/7comm/fluxo-consents-scripts/certs/transport.pem

requestEndpoint(){

  ENDPOINT=$1
  CONTEXT="open-banking/channels/v1"
  HOST="bdlapi01-rj01.modal.net.br:8246"
  echo "#####   /$CONTEXT/$ENDPOINT #####"

   URL="https://openbanking-dev.modal.net.br/Channels/channels/v1"
  #URL="http://bdwapp32-rj01.modal.net.br/UnarrangedAccountsOverdraft/unarranged-accounts-overdraft/v1"
  #URL=https://$HOST/$CONTEXT

  curl -v -k -X GET \
  "https://$HOST/$CONTEXT/$ENDPOINT?page=1&pageSize=25" \
  -H "accept: */*" \
    --cert ${TRANSPORT_CERT} \
    --key ${TRANSPORT_KEY} 

  echo  
  for (( i=0; i<${#options[*]}; i++ )); do 
    p=$(($i+1))
    echo "$p ) ${options[i]}"
  done 

  echo 

}

PS3='Please enter your choice: '
options=("banking-agent" "branches" "electronic-channels" "phone-channels" "shared-automated-teller-machines")
select opt in "${options[@]}"
do
    case $opt in
        "banking-agent")

             requestEndpoint   "banking-agent"
            ;;
        "branches")
            requestEndpoint   "branches"
            ;;
        "electronic-channels")
            requestEndpoint   "electronic-channels"
            ;;
        "phone-channels")
            requestEndpoint   "phone-channels"
            ;;
        "shared-automated-teller-machines")
            requestEndpoint   "shared-automated-teller-machines"
            ;;  
        *) echo "invalid option $REPLY";;
    esac
done
