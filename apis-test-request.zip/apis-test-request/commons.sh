#!/bin/bash

TRANSPORT_KEY=/home/wso2carbon/7comm/fluxo-consents-scripts/certs/transport.key
TRANSPORT_CERT=/home/wso2carbon/7comm/fluxo-consents-scripts/certs/transport.pem
  # "$URL/$ENDPOINT?page=1&pageSize=25" \

requestEndpoint(){

  ENDPOINT=$1
  CONTEXT="open-banking/discovery/v1"
  HOST="bdlapi01-rj01.modal.net.br:8246"
  echo "#####   /$CONTEXT/$ENDPOINT #####"

#  URL="https://openbanking-dev.modal.net.br/commons/discovery/v1"
  URL=https://$HOST/$CONTEXT

  curl -v -k -X GET \
    "$URL/$ENDPOINT" \
  -H "accept: */*" \
    --cert ${TRANSPORT_CERT} \
    --key ${TRANSPORT_KEY} 

  echo  
  for (( i=0; i<${#options[*]}; i++ )); do 
    p=$(($i+1))
    echo "$p ) ${options[i]}"
  done 

  echo 

}

PS3='Please enter your choice: '
options=("status" "outages")
select opt in "${options[@]}"
do
    case $opt in
        "status")
              requestEndpoint  "status"
            ;;
        "outages")
              requestEndpoint  "outages"
            ;;                                     
        *) echo "invalid option $REPLY";;
        
    esac
done

