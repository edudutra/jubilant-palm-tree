#!/bin/bash

TRANSPORT_KEY=/home/wso2carbon/7comm/fluxo-consents-scripts/certs/transport.key
TRANSPORT_CERT=/home/wso2carbon/7comm/fluxo-consents-scripts/certs/transport.pem
TOKEN="eyJ4NXQiOiJNell4TW1Ga09HWXdNV0kwWldObU5EY3hOR1l3WW1NNFpUQTNNV0kyTkRBelpHUXpOR00wWkdSbE5qSmtPREZrWkRSaU9URmtNV0ZoTXpVMlpHVmxOZyIsImtpZCI6Ik16WXhNbUZrT0dZd01XSTBaV05tTkRjeE5HWXdZbU00WlRBM01XSTJOREF6WkdRek5HTTBaR1JsTmpKa09ERmtaRFJpT1RGa01XRmhNelUyWkdWbE5nX1JTMjU2IiwiYWxnIjoiUlMyNTYifQ.eyJzdWIiOiJhZG1pbkB3c28yLmNvbUBjYXJib24uc3VwZXIiLCJhdXQiOiJBUFBMSUNBVElPTl9VU0VSIiwiYXVkIjoiVkFXNlMzd2lVU3dmSEZGek1zWE9mM3pFWV9RYSIsIm5iZiI6MTYyMzgwMjY1OCwiYXpwIjoiVkFXNlMzd2lVU3dmSEZGek1zWE9mM3pFWV9RYSIsInNjb3BlIjoiYWNjb3VudHMgb3BlbmlkIGxvYW5zIHVuYXJyYW5nZWQtYWNjb3VudHMtb3ZlcmRyYWZ0IiwiaXNzIjoiaHR0cHM6Ly9iZGxpczAxLXJqMDE6OTQ0Ni9vYXV0aDIvdG9rZW4iLCJjbmYiOnsieDV0I1MyNTYiOiJkbWlZNWRNN3BPNVc3aW44a1JhamZBcnF5VE1PbkZXMjlXQlVOa1FJWGU4In0sImV4cCI6MTY1MzgwNjI1OCwiaWF0IjoxNjI0Mzc4MzYyLCJqdGkiOiI4MjhhMjQ2MS0zMzY2LTRmNTctOGVlZC03MjE4OTA4MGQzMWUiLCJjb25zZW50X2lkIjoiNGI2ZmM0ZDQtZmI1OC00MDJkLWI0MjktZTJlMzI3OTEyZWQ0In0.mFEGlK23lo7uS8pCS67CHhkRYjNaH5PnFXunVZrlyGnZdlL3MU8itOb9xpL29uGCeESBY39GOPpB0OPhY6Eeyb-4d05HHQH-8fnxSv50RG048mySyZ7Z4TQBRfZ10bVF6dBrnKNGrUONmeNnSRqyOZnJC-g5DPlhL6iujwMFhVAaY-bQD0xZ0qMCOdSS_F6DIjzKjv9hasXG-Yd7GQvqx7Upq1MYcCRt1fsbBVxjMh7zyQQth-kQjZb6f2HLD9fK4l_9dBjdZ96UBRvvPqltXl3ZqaZHsTlyJEkmlvJHp4tZd6j-C3fjWWaW6RY9yYNrFlLRDlpBg-U5RrzFlqO2AA"

requestEndpoint(){

  ENDPOINT=$1
  CONTEXT="open-banking/credit-cards-accounts/v1"
  HOST="bdlapi01-rj01.modal.net.br:8246"
  echo "#####   /$CONTEXT/$ENDPOINT #####"

  #URL="httpS://bdwapp32-rj01.modal.net.br/UnarrangedAccountsOverdraft/unarranged-accounts-overdraft/v1"
  URL=https://$HOST/$CONTEXT

  curl -v -k -X GET \
  "$URL/$ENDPOINT?page=1&pageSize=25" \
  -H "accept: */*" \
  -H "Authorization: Bearer ${TOKEN}" \
    --cert ${TRANSPORT_CERT} \
    --key ${TRANSPORT_KEY} 

  echo  
  for (( i=0; i<${#options[*]}; i++ )); do 
    p=$(($i+1))
    echo "$p ) ${options[i]}"
  done 

  echo 

}

PS3='Please enter your choice: '
options=("accounts" "accounts/{creditCardAccountId}" "accounts/{creditCardAccountId}/limits" "accounts/{creditCardAccountId}/transactions" "accounts/{creditCardAccountId}/bills" "accounts/{creditCardAccountId}/bills/{billId}/transactions")
select opt in "${options[@]}"
do
    case $opt in
        "accounts")
             requestEndpoint "accounts"
            ;;
        "accounts/{creditCardAccountId}")
            requestEndpoint   "accounts/{creditCardAccountId}"
            ;;
        "accounts/{creditCardAccountId}/limits")
            requestEndpoint   "accounts/{creditCardAccountId}/limits"
            ;;
        "accounts/{creditCardAccountId}/transactions")
            requestEndpoint   "accounts/{creditCardAccountId}/transactions"
            ;;
        "accounts/{creditCardAccountId}/bills")
            requestEndpoint   "accounts/{creditCardAccountId}/bills"
            ;;  
        "accounts/{creditCardAccountId}/bills/{billId}/transactions")
            requestEndpoint   "accounts/{creditCardAccountId}/bills/{billId}/transactions"
            ;; 
        *) echo "invalid option $REPLY";;
    esac
done
