#!/bin/bash

TRANSPORT_KEY=/home/wso2carbon/7comm/fluxo-consents-scripts/certs/transport.key
TRANSPORT_CERT=/home/wso2carbon/7comm/fluxo-consents-scripts/certs/transport.pem
TOKEN="eyJ4NXQiOiJNell4TW1Ga09HWXdNV0kwWldObU5EY3hOR1l3WW1NNFpUQTNNV0kyTkRBelpHUXpOR00wWkdSbE5qSmtPREZrWkRSaU9URmtNV0ZoTXpVMlpHVmxOZyIsImtpZCI6Ik16WXhNbUZrT0dZd01XSTBaV05tTkRjeE5HWXdZbU00WlRBM01XSTJOREF6WkdRek5HTTBaR1JsTmpKa09ERmtaRFJpT1RGa01XRmhNelUyWkdWbE5nX1JTMjU2IiwiYWxnIjoiUlMyNTYifQ.eyJzdWIiOiJhZG1pbkB3c28yLmNvbUBjYXJib24uc3VwZXIiLCJhdXQiOiJBUFBMSUNBVElPTl9VU0VSIiwiYXVkIjoiekxtT2ZQMnVCSzJUZnE0UnFJellwMlE0Y0F3YSIsIm5iZiI6MTYyODAzMDEwMSwiYXpwIjoiekxtT2ZQMnVCSzJUZnE0UnFJellwMlE0Y0F3YSIsInNjb3BlIjoiYWNjb3VudHMgY29uc2VudHMgY3JlZGl0LWNhcmRzLWFjY291bnRzIGN1c3RvbWVycyBmaW5hbmNpbmdzIGludm9pY2UtZmluYW5jaW5ncyBsb2FucyBvcGVuaWQgcGF5bWVudHMgcmVzb3VyY2VzIHVuYXJyYW5nZWQtYWNjb3VudHMtb3ZlcmRyYWZ0IiwiaXNzIjoiaHR0cHM6XC9cL2JkbGlzMDEtcmowMS5tb2RhbC5uZXQuYnI6OTQ0Nlwvb2F1dGgyXC90b2tlbiIsImNuZiI6eyJ4NXQjUzI1NiI6InZZb1VZUlNRN0Nnb1l4Tk1XV096Qzh1TmZRcmlzNHBYUVgwWm1pdFJ4enMifSwiZXhwIjoxNjQ5NjMwMTAxLCJpYXQiOjE2MjgwMzAxMDEsImp0aSI6ImM3ZjU3Yzc0LTk3OTgtNDFjNi05YzRmLWRjOGNhZTRiNTk3YSIsImNvbnNlbnRfaWQiOiJ1cm46TW9kYWw6MjU4ZTAwNzMtZmU3Yi00YjY5LThkMzEtNjFhZTg1NzY1ODgyIn0.f4Kac7qOQecsb21CpeyVBPq1EY3PXo-0oZekuoGTWzsU2zIx20x9Tcz14YjCjzH_jQ2F8egIbReYqWhoQI3bE7x9eidk42WBRwLYgXjGr_BUki-bO7DgMMP5teB4VaseYpy0-aHR82XwBz8Gy5jG2PRJy5WmWSOuXvvKySqGLq14i9jvdz3okyy4lbcdkzECvgQOi4eyWzPZZNuh6hlW1X_uJc2jGQNBIAJOrKE50usuo7fgp64cu79k7GKoJU0VWydgplOlVG2_sgdU819LGqcIMs814y3RIonNDKx_kNsQkN5maTtJ4jOjjqnykK_FTltHAjjP06sicaKNCsZRzA"

requestEndpoint(){

  ENDPOINT=$1
  CONTEXT="open-banking/loans/v1"
  HOST="apigw-ob-dev.modal.net.br"
    
  CONTEXTMODAL="loans/loans/v1"
  HOSTMODAL="openbanking-dev.modal.net.br"
  echo "#####   /$CONTEXT/$ENDPOINT #####"


  curl -v -k -X GET \
  "https://$HOST/$CONTEXT/$ENDPOINT" \
  -H "Authorization: Bearer ${TOKEN}" \
  -H "accept: application/json" \
    --cert ${TRANSPORT_CERT} \
    --key ${TRANSPORT_KEY} 

  echo  
  for (( i=0; i<${#options[*]}; i++ )); do 
    p=$(($i+1))
    echo "$p ) ${options[i]}"
  done 

  echo 

}

PS3='Please enter your choice: '
options=("contracts" "contracts/1" "contracts/1/warranties" "contracts/1/payments" "contracts/1/scheduled-instalments")
select opt in "${options[@]}"
do
    case $opt in
        "contracts")

             requestEndpoint   "contract-list"
            ;;
        "contracts/1")
            requestEndpoint   "contracts/1"
            ;;
        "contracts/1/warranties")
            requestEndpoint   "contracts/1/warranties"
            ;;
        "contracts/1/payments")
            requestEndpoint   "contracts/1/payments"
            ;;
        "contracts/1/scheduled-instalments")
            requestEndpoint   "contracts/1/scheduled-instalments"
            ;;  
        *) echo "invalid option $REPLY";;
    esac
done
