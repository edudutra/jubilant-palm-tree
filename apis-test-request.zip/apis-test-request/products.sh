#!/bin/bash

TRANSPORT_KEY=/home/wso2carbon/7comm/fluxo-consents-scripts/certs/transport.key
TRANSPORT_CERT=/home/wso2carbon/7comm/fluxo-consents-scripts/certs/transport.pem

requestEndpoint(){

  ENDPOINT=$1
  CONTEXT="open-banking/products-services/v1"
  HOST="bdlapi01-rj01.modal.net.br:8246"
  echo "#####   /$CONTEXT/$ENDPOINT #####"

  curl -v -k -X GET \
  "https://$HOST/$CONTEXT/$ENDPOINT?page=1&pageSize=25" \
  -H "accept: */*" \
    --cert ${TRANSPORT_CERT} \
    --key ${TRANSPORT_KEY} 

  echo  
  for (( i=0; i<${#options[*]}; i++ )); do 
    p=$(($i+1))
    echo "$p ) ${options[i]}"
  done 

  echo 

}

PS3='Please enter your choice: '
options=("personal-accounts" "business-accounts" "personal-loans" "business-loans" "personal-financings" "business-financings" "personal-invoice-financings" "business-invoice-financings" "personal-credit-cards" "business-credit-cards" "personal-unarranged-account-overdraft" "business-unarranged-account-overdraft")
select opt in "${options[@]}"
do
    case $opt in
        "personal-accounts")
              requestEndpoint  "personal-accounts"
            ;;
        "business-accounts")
              requestEndpoint  "business-accounts"
            ;;
        "personal-loans")
              requestEndpoint  "personal-loans"
            ;;
        "business-loans")
              requestEndpoint  "business-loans"
            ;;
        "personal-financings")
              requestEndpoint  "personal-financings"
            ;;  
         "business-financings")
              requestEndpoint  "business-financings"
            ;;    
         "personal-invoice-financings")
              requestEndpoint  "personal-invoice-financings"
            ;;     
         "business-invoice-financings")
              requestEndpoint  "business-invoice-financings"
            ;;    
         "personal-credit-cards")
              requestEndpoint  "personal-credit-cards"
            ;;      
         "business-credit-cards")
              requestEndpoint  "personal-credit-cards"
            ;;      
         "personal-unarranged-account-overdraft")
              requestEndpoint  "personal-unarranged-account-overdraft"
            ;;      
         "business-unarranged-account-overdraft")
              requestEndpoint  "business-unarranged-account-overdraft"
            ;;                                                                  
        *) echo "invalid option $REPLY";;
        
    esac
done

