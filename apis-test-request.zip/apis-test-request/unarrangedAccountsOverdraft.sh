#!/bin/bash

TRANSPORT_KEY=/home/wso2carbon/7comm/fluxo-consents-scripts/certs/transport.key
TRANSPORT_CERT=/home/wso2carbon/7comm/fluxo-consents-scripts/certs/transport.pem
# TOKEN="eyJ4NXQiOiJNell4TW1Ga09HWXdNV0kwWldObU5EY3hOR1l3WW1NNFpUQTNNV0kyTkRBelpHUXpOR00wWkdSbE5qSmtPREZrWkRSaU9URmtNV0ZoTXpVMlpHVmxOZyIsImtpZCI6Ik16WXhNbUZrT0dZd01XSTBaV05tTkRjeE5HWXdZbU00WlRBM01XSTJOREF6WkdRek5HTTBaR1JsTmpKa09ERmtaRFJpT1RGa01XRmhNelUyWkdWbE5nX1JTMjU2IiwiYWxnIjoiUlMyNTYifQ.eyJzdWIiOiJhZG1pbkB3c28yLmNvbUBjYXJib24uc3VwZXIiLCJhdXQiOiJBUFBMSUNBVElPTl9VU0VSIiwiYXVkIjoiekxtT2ZQMnVCSzJUZnE0UnFJellwMlE0Y0F3YSIsIm5iZiI6MTYyODAzMDEwMSwiYXpwIjoiekxtT2ZQMnVCSzJUZnE0UnFJellwMlE0Y0F3YSIsInNjb3BlIjoiYWNjb3VudHMgY29uc2VudHMgY3JlZGl0LWNhcmRzLWFjY291bnRzIGN1c3RvbWVycyBmaW5hbmNpbmdzIGludm9pY2UtZmluYW5jaW5ncyBsb2FucyBvcGVuaWQgcGF5bWVudHMgcmVzb3VyY2VzIHVuYXJyYW5nZWQtYWNjb3VudHMtb3ZlcmRyYWZ0IiwiaXNzIjoiaHR0cHM6XC9cL2JkbGlzMDEtcmowMS5tb2RhbC5uZXQuYnI6OTQ0Nlwvb2F1dGgyXC90b2tlbiIsImNuZiI6eyJ4NXQjUzI1NiI6InZZb1VZUlNRN0Nnb1l4Tk1XV096Qzh1TmZRcmlzNHBYUVgwWm1pdFJ4enMifSwiZXhwIjoxNjQ5NjMwMTAxLCJpYXQiOjE2MjgwMzAxMDEsImp0aSI6ImM3ZjU3Yzc0LTk3OTgtNDFjNi05YzRmLWRjOGNhZTRiNTk3YSIsImNvbnNlbnRfaWQiOiJ1cm46TW9kYWw6MjU4ZTAwNzMtZmU3Yi00YjY5LThkMzEtNjFhZTg1NzY1ODgyIn0.f4Kac7qOQecsb21CpeyVBPq1EY3PXo-0oZekuoGTWzsU2zIx20x9Tcz14YjCjzH_jQ2F8egIbReYqWhoQI3bE7x9eidk42WBRwLYgXjGr_BUki-bO7DgMMP5teB4VaseYpy0-aHR82XwBz8Gy5jG2PRJy5WmWSOuXvvKySqGLq14i9jvdz3okyy4lbcdkzECvgQOi4eyWzPZZNuh6hlW1X_uJc2jGQNBIAJOrKE50usuo7fgp64cu79k7GKoJU0VWydgplOlVG2_sgdU819LGqcIMs814y3RIonNDKx_kNsQkN5maTtJ4jOjjqnykK_FTltHAjjP06sicaKNCsZRzA"
TOKEN="eyJ4NXQiOiJNell4TW1Ga09HWXdNV0kwWldObU5EY3hOR1l3WW1NNFpUQTNNV0kyTkRBelpHUXpOR00wWkdSbE5qSmtPREZrWkRSaU9URmtNV0ZoTXpVMlpHVmxOZyIsImtpZCI6Ik16WXhNbUZrT0dZd01XSTBaV05tTkRjeE5HWXdZbU00WlRBM01XSTJOREF6WkdRek5HTTBaR1JsTmpKa09ERmtaRFJpT1RGa01XRmhNelUyWkdWbE5nX1JTMjU2IiwiYWxnIjoiUlMyNTYifQ.eyJzdWIiOiJhZG1pbkB3c28yLmNvbUBjYXJib24uc3VwZXIiLCJhdXQiOiJBUFBMSUNBVElPTl9VU0VSIiwiYXVkIjoiekxtT2ZQMnVCSzJUZnE0UnFJellwMlE0Y0F3YSIsIm5iZiI6MTYyODAzODE5NSwiYXpwIjoiekxtT2ZQMnVCSzJUZnE0UnFJellwMlE0Y0F3YSIsInNjb3BlIjoiYWNjb3VudHMgY29uc2VudHMgY3JlZGl0LWNhcmRzLWFjY291bnRzIGN1c3RvbWVycyBmaW5hbmNpbmdzIGludm9pY2UtZmluYW5jaW5ncyBsb2FucyBvcGVuaWQgcGF5bWVudHMgcmVzb3VyY2VzIHVuYXJyYW5nZWQtYWNjb3VudHMtb3ZlcmRyYWZ0IiwiaXNzIjoiaHR0cHM6XC9cL2JkbGlzMDEtcmowMS5tb2RhbC5uZXQuYnI6OTQ0Nlwvb2F1dGgyXC90b2tlbiIsImNuZiI6eyJ4NXQjUzI1NiI6InZZb1VZUlNRN0Nnb1l4Tk1XV096Qzh1TmZRcmlzNHBYUVgwWm1pdFJ4enMifSwiZXhwIjoxNjQ5NjM4MTk1LCJpYXQiOjE2MjgwMzgxOTUsImp0aSI6IjRjNTYxYTdjLWM3MWEtNDlhZC04ZDQ4LTc4MzU2OWRhMWFlZCIsImNvbnNlbnRfaWQiOiJ1cm46TW9kYWw6YTJiNWJmNzMtZGFjZi00ZjA5LThiMzItNGQwM2ZjODNlZmQ5In0.F0B_WjSXUMGjUlE4GSKnfktf5_oVaGyVrZgc0YYkJ4BZb9Rjp5dGSbSuuJ5i_lT0BZXQc1gbv-KzUoLegVzIaOmAqDwaxltFwxE0NGWNfhfS-VMwS8fhZkX8TVjc5Iu4rETUV4hs9K1imZvh1wiaZ68aE27tPAHg6RWV5Jj2B3r-9jsivO233afzUJhCleGRYtIksuO53mhd9xtGQPYuX5XNyZrESs3wmb2p_vWwgkzguVov0j64a7DmHhKk0EnlKgFJ4ecA6rDTIKalZeNE8u20rAEIJNvEgsjjWibQohcxCx-mPpcUF3lE28GllHOBITFf98yhRpbXjxmOMpmU_w"
requestEndpoint(){

  ENDPOINT=$1
  CONTEXT="open-banking/unarranged-accounts-overdraft/v1"
  HOST="bdlapi01-rj01.modal.net.br:8246"

  echo "#####   /$CONTEXT/$ENDPOINT #####"
#   URL="https://openbanking-dev.modal.net.br/UnarrangedAccountsOverdraft/unarranged-accounts-overdraft/v1"
  #URL="http://bdwapp32-rj01.modal.net.br/UnarrangedAccountsOverdraft/unarranged-accounts-overdraft/v1"
  #URL=https://$HOST/$CONTEXT
  URL="https://apigw-ob-dev.modal.net.br/open-banking/unarranged-accounts-overdraft/v1/contracts"
  
  curl -v -k -X GET \
  "$URL/$ENDPOINT?page=1&pageSize=25" \
  -H "Authorization: Bearer ${TOKEN}" \
  -H "accept: application/json"
    # --cert ${TRANSPORT_CERT} \
    # --key ${TRANSPORT_KEY} 

  echo "curl -v -k -X GET  $URL/$ENDPOINT?page=1&pageSize=25" -H "Authorization: Bearer ${TOKEN}" -H "accept: application/json"  

  echo  
  for (( i=0; i<${#options[*]}; i++ )); do 
    p=$(($i+1))
    echo "$p ) ${options[i]}"
  done 

  echo 

}

PS3='Please enter your choice: '
options=("contracts" "contracts/{contractId}" "contracts/{contractId}/warranties" "contracts/{contractId}/payments" "contracts/{contractId}/scheduled-instalments")
select opt in "${options[@]}"
do
    case $opt in
        "contracts")

             requestEndpoint   "contracts"
            ;;
        "contracts/{contractId}")
            requestEndpoint   "contracts/4b6fc4d4-fb58-402d-b429-e2e327912ed4"
            ;;
        "contracts/{contractId}/warranties")
            requestEndpoint   "contracts/4b6fc4d4-fb58-402d-b429-e2e327912ed4/warranties"
            ;;
        "contracts/{contractId}/payments")
            requestEndpoint   "contracts/4b6fc4d4-fb58-402d-b429-e2e327912ed4/payments"
            ;;
        "contracts/{contractId}/scheduled-instalments")
            requestEndpoint   "contracts/4b6fc4d4-fb58-402d-b429-e2e327912ed4/scheduled-instalments"
            ;;  
        *) echo "invalid option $REPLY";;
    esac
done
