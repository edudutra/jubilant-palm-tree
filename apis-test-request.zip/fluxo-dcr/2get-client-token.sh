TRANSPORT_KEY=/home/wso2carbon/7comm/fluxo-consents-scripts/certs/transport.key
TRANSPORT_CERT=/home/wso2carbon/7comm/fluxo-consents-scripts/certs/transport.pem

SCOPE="consents"
CLIENT_ASSERTION="eyJraWQiOiIyTUk5WFNLaTZkZHhDYldnMnJoRE50VWx4SmMiLCJhbGciOiJQUzI1NiJ9.eyJzdWIiOiJ6TG1PZlAydUJLMlRmcTRScUl6WXAyUTRjQXdhIiwiYXVkIjoiaHR0cHM6Ly9iZGxpczAxLXJqMDEubW9kYWwubmV0LmJyOjk0NDYvb2F1dGgyL3Rva2VuIiwiaXNzIjoiekxtT2ZQMnVCSzJUZnE0UnFJellwMlE0Y0F3YSIsImV4cCI6MTYzMjgwMTkyNjEsImlhdCI6MTYyODAzNTI0MiwianRpIjoiMTYyODAxOTI2OSJ9.fo4jr9jAkpsZhaY7HxpDsjnVGgCmLDk8ar02l0ruxownF3mvbsCPuRByRP75DS2OmWnPG3HptiCVtwHrVVFa4VFCvjRjWtj2OV4yudEWLY4LdUZH6MPSxwhEUGETaxZ7aB8rYyps_HH22-ZZ_WXcrAl-7VwN45NK6WL6A27R4nABrBTCnJYfkvs-GvmDrUwdjs2JDejM9swswL2g4CuHEFOvvKagPUgLEVSOG1QOoNVcoXBf8ejE7ZDCY6ZgjwWqYBqu1A9jl9yiQe2Erzn_2vWD7o4Q6w_FRmVx2lky0TME-1QbK75Ver_jtFX310QjMiicwNIOD3Uy56BhOB5vsQ"

curl -v -k -X POST \
https://bdlis01-rj01.modal.net.br:9446/oauth2/token \
  -H 'Cache-Control: no-cache' \
  -H 'Content-Type: application/x-www-form-urlencoded' \
  -H 'Accept: application/json' \
  --cert ${TRANSPORT_CERT} \
  --key ${TRANSPORT_KEY} \
-d "grant_type=client_credentials&scope=${SCOPE}&client_assertion=${CLIENT_ASSERTION}&client_assertion_type=urn%3Aietf%3Aparams%3Aoauth%3Aclient-assertion-type%3Ajwt-bearer&redirect_uri=www.wso2.com"




# P_adYZPZfsmltS8GIMmyzSf664wa

