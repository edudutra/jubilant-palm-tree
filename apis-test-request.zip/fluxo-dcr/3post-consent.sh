TRANSPORT_KEY=/home/wso2carbon/7comm/fluxo-consents-scripts/certs/transport.key
TRANSPORT_CERT=/home/wso2carbon/7comm/fluxo-consents-scripts/certs/transport.pem

TOKEN="eyJ4NXQiOiJNell4TW1Ga09HWXdNV0kwWldObU5EY3hOR1l3WW1NNFpUQTNNV0kyTkRBelpHUXpOR00wWkdSbE5qSmtPREZrWkRSaU9URmtNV0ZoTXpVMlpHVmxOZyIsImtpZCI6Ik16WXhNbUZrT0dZd01XSTBaV05tTkRjeE5HWXdZbU00WlRBM01XSTJOREF6WkdRek5HTTBaR1JsTmpKa09ERmtaRFJpT1RGa01XRmhNelUyWkdWbE5nX1JTMjU2IiwiYWxnIjoiUlMyNTYifQ.eyJzdWIiOiJhZG1pbkB3c28yLmNvbUBjYXJib24uc3VwZXIiLCJhdXQiOiJBUFBMSUNBVElPTiIsImF1ZCI6InpMbU9mUDJ1QksyVGZxNFJxSXpZcDJRNGNBd2EiLCJuYmYiOjE2MjgwODI4MTEsImF6cCI6InpMbU9mUDJ1QksyVGZxNFJxSXpZcDJRNGNBd2EiLCJzY29wZSI6ImFjY291bnRzIGNvbnNlbnRzIHBheW1lbnRzIiwiaXNzIjoiaHR0cHM6XC9cL2JkbGlzMDEtcmowMS5tb2RhbC5uZXQuYnI6OTQ0Nlwvb2F1dGgyXC90b2tlbiIsImNuZiI6eyJ4NXQjUzI1NiI6InZZb1VZUlNRN0Nnb1l4Tk1XV096Qzh1TmZRcmlzNHBYUVgwWm1pdFJ4enMifSwiZXhwIjoxNjQ5NjgyODExLCJpYXQiOjE2MjgwODI4MTEsImp0aSI6IjdkMjkwYjBjLWE4MDItNGJiNi05Y2M0LTMzYjhiM2U5ZDVjNSJ9.IpSYuZ4nIc20OfkM1nHCc5Ox2EKwbGrLTXca5Yt0WY38TjPhwYGVVP6j1C8Ont5S1RkjqXnuPl3iCMNNgM3EW7nQua3oanJLdqfhm0krmGiKe7c_-_yHY4liAG_mlah7O5RoZwTNsNh-YxciHtuIvkWPhkJ5fCOhxAm-xhKCBwLQdrv2K6WCj6F_KfkCgMX9_5gW7eTZoCUlJlblBOeECdWmgTUWj87gFWwsih_hfO-O2J24j8vns5DFYf7QQX0v8qdz4BpSsl-ynCISHCN0cx0ev3R0rIe8QfRlcKBnKCBcbIbbdeZmctr9U9AkopT1UM-ke4jkgjFY_yirpH4rBg"

# urn:Modal:595e21b4-c3cb-4324-8c31-14fc84843788
# https://bdlapi01-rj01.modal.net.br:8246/open-banking/consents/v1/consents

curl -v -k -X POST \
https://apigw-ob-dev.modal.net.br/open-banking/consents/v1/consents \
-H "Authorization: Bearer ${TOKEN}" \
-H 'Content-Type: application/json' \
  --cert ${TRANSPORT_CERT} \
  --key ${TRANSPORT_KEY} \
-d '{
    "data": {
    "loggedUser": {
      "document": {
        "identification": "22222222222",
        "rel": "CPF"
      }
    },
    "businessEntity": {
      "document": {
        "identification": "22222222222222",
        "rel": "CNPJ"
      }
    },
    "permissions": [
      "ACCOUNTS_READ"
    ],
    "expirationDateTime": "2021-09-21T08:30:00Z",
    "transactionFromDateTime": "2021-01-01T00:00:00Z",
    "transactionToDateTime": "2022-02-01T23:59:59Z"
  }
}
'
