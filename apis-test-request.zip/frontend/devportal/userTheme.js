const Configurations = {
    /*
     This file can be used to override the configurations in devportal/source/src/defaultTheme.js
     ex. Uncomment the below section to enable the landingPage
     */
     /*
     custom: {
         landingPage: {
             active: true,
         },
     },
     */
    custom: {
        appBar: {
            logo: '/site/public/modal-theme/images/logo.svg',
            logoHeight: 60, 
            logoWidth: 190,
            background: '#0B1C2C',
            backgroundImage: '/site/public/images/appbarBack.png',
            searchInputBackground: '#fff',
            searchInputActiveBackground: '#fff',
            activeBackground: '#0B1C2C',
            showSearch: true,
            drawerWidth: 200,
        },

        footer: {
            active: true,
            footerHTML: '',
            text: '', // Leave empty to show the default WSO2 Text. Provide custom text to display your own thing.
            background: '#000',
            color: '#fff',
            height: 50,
        },
        leftMenu: {
            position: 'vertical-left', // Sets the position of the left menu ( 'horizontal', 'vertical-left', 'vertical-right')
            style: 'icon left', //  other values ('icon top', 'icon left', 'no icon', 'no text')
            iconSize: 24,
            leftMenuTextStyle: 'uppercase',
            width: 180,
            background: '#0B1C2C',
            backgroundImage: '/site/public/images/leftMenuBack.png',
            leftMenuActive: '#00597f',
            leftMenuActiveSubmenu: '#0d1723',
            activeBackground: '#191e46',
            rootIconVisible: false,
            rootIconSize: 42,
            rootIconTextVisible: false,
            rootBackground: '#000',
        },
    }
};