/**
 * IMPORTANT: This file only contains theme JSS of the Publisher app, Don't add other configuration parameters here.
 * This theme file is an extension of material-ui default theme https://material-ui.com/customization/default-theme/
 * Application related configurations are located in `<PUBLISHER_ROOT>site/public/theme/settings.js`
 */
const userThemes = {
    light(theme) {
        return (
            {
                overrides: {
                    MuiDrawer: {
                        paper: {
                            // backgroundColor: '#882621',
                        },
                    },
                    MuiRadio: {
                        colorSecondary: {
                            '&$checked': { color: theme.palette.primary.main },
                            '&$disabled': {
                                color: theme.palette.action.disabled,
                            },
                        },
                    },
                },

                custom: {
                    logo: '/site/public/modal-theme/images/logo.svg',
                    logoHeight: 60, 
                    logoWidth: 190,
                },

                palette: {
                    background: {
                        appBar: '#0B1C2C',
                        leftMenu: '#0B1C2C',
                        leftMenuActive: '#25B2AA',
                    }
                }
            }
        );
    },
};
if (typeof module !== 'undefined') {
    module.exports = userThemes; // Added for tests
}
